package com.elainashield.obfuscator.transformers;

import com.elainashield.obfuscator.core.ObfuscationConfig;
import com.elainashield.obfuscator.core.ObfuscationContext;
import com.elainashield.obfuscator.utils.NameGenerator;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.*;

import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║            Junk Code Injection Transformer                       ║
 * ╠══════════════════════════════════════════════════════════════════╣
 * ║ Injects various types of dead/junk code to bloat the binary     ║
 * ║ and confuse decompilers:                                        ║
 * ║                                                                  ║
 * ║ 1. JUNK METHODS: Entire fake methods with complex-looking but   ║
 * ║    meaningless logic (loops, math, string manipulation)          ║
 * ║                                                                  ║
 * ║ 2. JUNK FIELDS: Static fields initialized with garbage values   ║
 * ║                                                                  ║
 * ║ 3. OPAQUE PREDICATES: Conditions that always evaluate to the    ║
 * ║    same value but look complex (e.g., x*x >= 0 is always true)  ║
 * ║                                                                  ║
 * ║ 4. INLINE DEAD CODE: Unreachable code blocks inserted inline    ║
 * ║    within existing methods behind opaque predicates              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */
public class JunkCodeTransformer {

    private final ObfuscationConfig config;
    private final ObfuscationContext context;
    private final NameGenerator nameGen;
    private final Random random;

    /** Track whether we've already placed an Elaina signature in the current class */
    private boolean elainaPlacedInCurrentClass = false;

    /** Number of junk methods to add per class */
    private static final int JUNK_METHODS_PER_CLASS_MIN = 15;
    private static final int JUNK_METHODS_PER_CLASS_MAX = 30;

    /** Number of junk fields to add per class */
    private static final int JUNK_FIELDS_PER_CLASS_MIN = 10;
    private static final int JUNK_FIELDS_PER_CLASS_MAX = 20;

    /** Aggressive mode multiplier */
    private static final int AGGRESSIVE_MULTIPLIER = 5;

    /** JVM hard limit for method bytecode: 65535 bytes. We use 60KB as safety threshold. */
    @SuppressWarnings("unused")
    private static final int MAX_METHOD_BYTES = 65535;
    private static final int SAFE_METHOD_BYTES = 60 * 1024; // 60KB safety margin

    public JunkCodeTransformer(ObfuscationConfig config, ObfuscationContext context, NameGenerator nameGen) {
        this.config = config;
        this.context = context;
        this.nameGen = nameGen;
        this.random = nameGen.getRandom();
    }

    /**
     * Apply junk code injection to all classes.
     */
    public void transform(List<ClassNode> classes) {
        System.out.println("  [JunkCode] Injecting junk code...");

        int totalMethods = 0;
        int totalFields = 0;
        int totalInlineJunk = 0;

        for (ClassNode cn : classes) {
            // Skip interfaces and annotations
            if ((cn.access & (Opcodes.ACC_INTERFACE | Opcodes.ACC_ANNOTATION)) != 0) {
                continue;
            }
            if (context.isClassExcluded(cn.name)) {
                continue;
            }

            // Reset per-class Elaina signature flag
            elainaPlacedInCurrentClass = false;

            // 1. Add junk fields
            int fieldCount = randomRange(JUNK_FIELDS_PER_CLASS_MIN, JUNK_FIELDS_PER_CLASS_MAX);
            if (config.isAggressiveMode()) fieldCount *= AGGRESSIVE_MULTIPLIER;
            for (int i = 0; i < fieldCount; i++) {
                cn.fields.add(generateJunkField());
            }
            totalFields += fieldCount;

            // 2. Add junk methods
            int methodCount = randomRange(JUNK_METHODS_PER_CLASS_MIN, JUNK_METHODS_PER_CLASS_MAX);
            if (config.isAggressiveMode()) methodCount *= AGGRESSIVE_MULTIPLIER;
            for (int i = 0; i < methodCount; i++) {
                cn.methods.add(generateJunkMethod(cn));
            }
            totalMethods += methodCount;

            // 3. Insert inline dead code into existing methods
            for (MethodNode mn : cn.methods) {
                if (canInjectInline(mn)) {
                    int injected = injectInlineDeadCode(mn);
                    totalInlineJunk += injected;
                }
            }
        }

        context.addJunkMethods(totalMethods);
        context.addJunkFields(totalFields);

        System.out.println("  [JunkCode] Injected: " + totalMethods + " methods, " +
                totalFields + " fields, " + totalInlineJunk + " inline blocks");
    }

    // ==================================================================
    // JUNK FIELD GENERATION
    // ==================================================================

    private FieldNode generateJunkField() {
        String name = nameGen.nextFieldName();
        int choice = random.nextInt(5);
        String desc;
        Object value = null;

        switch (choice) {
            case 0:
                desc = "I"; // int
                value = random.nextInt();
                break;
            case 1:
                desc = "J"; // long
                value = random.nextLong();
                break;
            case 2:
                desc = "Ljava/lang/String;"; // String
                value = generateGarbageString();
                break;
            case 3:
                desc = "D"; // double
                value = random.nextDouble() * 1000;
                break;
            case 4:
                desc = "Z"; // boolean
                value = random.nextBoolean() ? 1 : 0;
                break;
            default:
                desc = "I";
                value = 0;
        }

        int access = Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC;
        if (random.nextBoolean()) access |= Opcodes.ACC_FINAL;

        return new FieldNode(access, name, desc, null, value);
    }

    private String generateGarbageString() {
        int len = 8 + random.nextInt(24);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append((char) (0x20 + random.nextInt(95))); // printable ASCII
        }
        return sb.toString();
    }

    // ==================================================================
    // JUNK METHOD GENERATION
    // ==================================================================

    /**
     * Generate a complete junk method with complex-looking but meaningless logic.
     * Multiple templates are used for variety.
     */
    private MethodNode generateJunkMethod(ClassNode owner) {
        int template = random.nextInt(6);
        switch (template) {
            case 0: return generateMathJunkMethod();
            case 1: return generateLoopJunkMethod();
            case 2: return generateStringJunkMethod();
            case 3: return generateArrayJunkMethod();
            case 4: return generateBitManipJunkMethod();
            case 5: return generateNestedConditionJunkMethod();
            default: return generateMathJunkMethod();
        }
    }

    /**
     * Template 1: Mathematical computation junk
     * Generates: int method(int a, int b) { return ((a * MAGIC) ^ b) + CONST; }
     */
    private MethodNode generateMathJunkMethod() {
        String name = nameGen.nextJunkMethodName();
        MethodNode mn = new MethodNode(
                Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC,
                name, "(II)I", null, null);

        InsnList insns = mn.instructions;

        // Complex math that looks important but is never called
        insns.add(new VarInsnNode(Opcodes.ILOAD, 0));
        pushInt(insns, random.nextInt(1000) + 1);
        insns.add(new InsnNode(Opcodes.IMUL));
        insns.add(new VarInsnNode(Opcodes.ILOAD, 1));
        insns.add(new InsnNode(Opcodes.IXOR));
        pushInt(insns, random.nextInt(0xFFFF));
        insns.add(new InsnNode(Opcodes.IADD));

        // More operations for complexity
        insns.add(new InsnNode(Opcodes.DUP));
        pushInt(insns, 16);
        insns.add(new InsnNode(Opcodes.ISHR));
        insns.add(new InsnNode(Opcodes.IXOR));
        pushInt(insns, 0x45D9F3B);
        insns.add(new InsnNode(Opcodes.IMUL));

        insns.add(new InsnNode(Opcodes.IRETURN));

        mn.maxStack = 4;
        mn.maxLocals = 2;
        return mn;
    }

    /**
     * Template 2: Loop-based junk
     * Generates a method with a for loop that computes something useless
     */
    private MethodNode generateLoopJunkMethod() {
        String name = nameGen.nextJunkMethodName();
        MethodNode mn = new MethodNode(
                Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC,
                name, "(I)J", null, null);

        InsnList insns = mn.instructions;

        // long result = 0;
        insns.add(new InsnNode(Opcodes.LCONST_0));
        insns.add(new VarInsnNode(Opcodes.LSTORE, 1)); // result at slot 1-2

        // int i = 0;
        insns.add(new InsnNode(Opcodes.ICONST_0));
        insns.add(new VarInsnNode(Opcodes.ISTORE, 3)); // i at slot 3

        // Loop start
        LabelNode loopStart = new LabelNode();
        LabelNode loopEnd = new LabelNode();
        insns.add(loopStart);

        // if (i >= param) goto end
        insns.add(new VarInsnNode(Opcodes.ILOAD, 3));
        insns.add(new VarInsnNode(Opcodes.ILOAD, 0));
        insns.add(new JumpInsnNode(Opcodes.IF_ICMPGE, loopEnd));

        // result += (i * MAGIC) ^ (result >>> 16)
        insns.add(new VarInsnNode(Opcodes.LLOAD, 1));
        insns.add(new VarInsnNode(Opcodes.ILOAD, 3));
        pushInt(insns, random.nextInt(10000) + 1);
        insns.add(new InsnNode(Opcodes.IMUL));
        insns.add(new InsnNode(Opcodes.I2L));
        insns.add(new VarInsnNode(Opcodes.LLOAD, 1));
        pushInt(insns, 16);
        insns.add(new InsnNode(Opcodes.LUSHR));
        insns.add(new InsnNode(Opcodes.LXOR));
        insns.add(new InsnNode(Opcodes.LADD));
        insns.add(new VarInsnNode(Opcodes.LSTORE, 1));

        // i++
        insns.add(new IincInsnNode(3, 1));
        insns.add(new JumpInsnNode(Opcodes.GOTO, loopStart));

        insns.add(loopEnd);
        insns.add(new VarInsnNode(Opcodes.LLOAD, 1));
        insns.add(new InsnNode(Opcodes.LRETURN));

        mn.maxStack = 6;
        mn.maxLocals = 4;
        return mn;
    }

    /**
     * Template 3: String manipulation junk
     */
    private MethodNode generateStringJunkMethod() {
        String name = nameGen.nextJunkMethodName();
        MethodNode mn = new MethodNode(
                Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC,
                name, "(Ljava/lang/String;)Ljava/lang/String;", null, null);

        InsnList insns = mn.instructions;

        // StringBuilder sb = new StringBuilder();
        insns.add(new TypeInsnNode(Opcodes.NEW, "java/lang/StringBuilder"));
        insns.add(new InsnNode(Opcodes.DUP));
        insns.add(new MethodInsnNode(Opcodes.INVOKESPECIAL,
                "java/lang/StringBuilder", "<init>", "()V", false));
        insns.add(new VarInsnNode(Opcodes.ASTORE, 1));

        // sb.append(param).append("GARBAGE")
        insns.add(new VarInsnNode(Opcodes.ALOAD, 1));
        insns.add(new VarInsnNode(Opcodes.ALOAD, 0));
        insns.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,
                "java/lang/StringBuilder", "append",
                "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false));
        insns.add(new LdcInsnNode(generateGarbageString()));
        insns.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,
                "java/lang/StringBuilder", "append",
                "(Ljava/lang/String;)Ljava/lang/StringBuilder;", false));
        insns.add(new InsnNode(Opcodes.POP));

        // return sb.toString()
        insns.add(new VarInsnNode(Opcodes.ALOAD, 1));
        insns.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,
                "java/lang/StringBuilder", "toString",
                "()Ljava/lang/String;", false));
        insns.add(new InsnNode(Opcodes.ARETURN));

        mn.maxStack = 4;
        mn.maxLocals = 2;
        return mn;
    }

    /**
     * Template 4: Array manipulation junk
     */
    private MethodNode generateArrayJunkMethod() {
        String name = nameGen.nextJunkMethodName();
        MethodNode mn = new MethodNode(
                Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC,
                name, "(I)[I", null, null);

        InsnList insns = mn.instructions;

        int arraySize = 16 + random.nextInt(48);

        // int[] arr = new int[SIZE];
        pushInt(insns, arraySize);
        insns.add(new IntInsnNode(Opcodes.NEWARRAY, Opcodes.T_INT));
        insns.add(new VarInsnNode(Opcodes.ASTORE, 1));

        // Fill array with pseudo-random values
        for (int i = 0; i < Math.min(arraySize, 8); i++) {
            insns.add(new VarInsnNode(Opcodes.ALOAD, 1));
            pushInt(insns, i);
            pushInt(insns, random.nextInt());
            insns.add(new InsnNode(Opcodes.IASTORE));
        }

        // Shuffle with XOR swap
        insns.add(new VarInsnNode(Opcodes.ALOAD, 1));
        pushInt(insns, 0);
        insns.add(new InsnNode(Opcodes.IALOAD));
        insns.add(new VarInsnNode(Opcodes.ALOAD, 1));
        pushInt(insns, 1);
        insns.add(new InsnNode(Opcodes.IALOAD));
        insns.add(new InsnNode(Opcodes.IXOR));
        insns.add(new InsnNode(Opcodes.POP));

        // return arr
        insns.add(new VarInsnNode(Opcodes.ALOAD, 1));
        insns.add(new InsnNode(Opcodes.ARETURN));

        mn.maxStack = 4;
        mn.maxLocals = 2;
        return mn;
    }

    /**
     * Template 5: Bit manipulation junk
     */
    private MethodNode generateBitManipJunkMethod() {
        String name = nameGen.nextJunkMethodName();
        MethodNode mn = new MethodNode(
                Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC,
                name, "(JI)J", null, null);

        InsnList insns = mn.instructions;

        // Complex bit manipulation
        insns.add(new VarInsnNode(Opcodes.LLOAD, 0)); // param1 (long, slots 0-1)
        insns.add(new VarInsnNode(Opcodes.ILOAD, 2)); // param2 (int, slot 2)
        insns.add(new InsnNode(Opcodes.LSHL));

        insns.add(new VarInsnNode(Opcodes.LLOAD, 0));
        pushInt(insns, 32);
        insns.add(new InsnNode(Opcodes.LUSHR));
        insns.add(new InsnNode(Opcodes.LXOR));

        insns.add(new LdcInsnNode(0x5DEECE66DL));
        insns.add(new InsnNode(Opcodes.LMUL));
        insns.add(new LdcInsnNode(0xBL));
        insns.add(new InsnNode(Opcodes.LADD));

        insns.add(new InsnNode(Opcodes.LRETURN));

        mn.maxStack = 4;
        mn.maxLocals = 3;
        return mn;
    }

    /**
     * Template 6: Nested conditions junk
     */
    private MethodNode generateNestedConditionJunkMethod() {
        String name = nameGen.nextJunkMethodName();
        MethodNode mn = new MethodNode(
                Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC,
                name, "(III)I", null, null);

        InsnList insns = mn.instructions;

        LabelNode l1 = new LabelNode();
        LabelNode l2 = new LabelNode();
        LabelNode l3 = new LabelNode();

        // if (a > b)
        insns.add(new VarInsnNode(Opcodes.ILOAD, 0));
        insns.add(new VarInsnNode(Opcodes.ILOAD, 1));
        insns.add(new JumpInsnNode(Opcodes.IF_ICMPLE, l1));

        // a * c + MAGIC
        insns.add(new VarInsnNode(Opcodes.ILOAD, 0));
        insns.add(new VarInsnNode(Opcodes.ILOAD, 2));
        insns.add(new InsnNode(Opcodes.IMUL));
        pushInt(insns, random.nextInt(1000));
        insns.add(new InsnNode(Opcodes.IADD));
        insns.add(new InsnNode(Opcodes.IRETURN));

        // else if (b > c)
        insns.add(l1);
        insns.add(new VarInsnNode(Opcodes.ILOAD, 1));
        insns.add(new VarInsnNode(Opcodes.ILOAD, 2));
        insns.add(new JumpInsnNode(Opcodes.IF_ICMPLE, l2));

        insns.add(new VarInsnNode(Opcodes.ILOAD, 1));
        insns.add(new VarInsnNode(Opcodes.ILOAD, 0));
        insns.add(new InsnNode(Opcodes.ISUB));
        pushInt(insns, random.nextInt(500));
        insns.add(new InsnNode(Opcodes.IXOR));
        insns.add(new InsnNode(Opcodes.IRETURN));

        // else if (c > a)
        insns.add(l2);
        insns.add(new VarInsnNode(Opcodes.ILOAD, 2));
        insns.add(new VarInsnNode(Opcodes.ILOAD, 0));
        insns.add(new JumpInsnNode(Opcodes.IF_ICMPLE, l3));

        insns.add(new VarInsnNode(Opcodes.ILOAD, 2));
        insns.add(new VarInsnNode(Opcodes.ILOAD, 1));
        insns.add(new InsnNode(Opcodes.IADD));
        pushInt(insns, random.nextInt(128));
        insns.add(new InsnNode(Opcodes.IXOR));
        insns.add(new InsnNode(Opcodes.IRETURN));

        // else (fallback)
        insns.add(l3);
        insns.add(new VarInsnNode(Opcodes.ILOAD, 2));
        pushInt(insns, random.nextInt(256));
        insns.add(new InsnNode(Opcodes.IAND));
        insns.add(new InsnNode(Opcodes.IRETURN));

        mn.maxStack = 4;
        mn.maxLocals = 3;
        return mn;
    }

    // ==================================================================
    // INLINE DEAD CODE INJECTION
    // ==================================================================

    private boolean canInjectInline(MethodNode mn) {
        if ((mn.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) != 0) return false;
        if (mn.name.startsWith("<")) return false;
        if (mn.instructions.size() < 4) return false;
        return true;
    }

    /**
     * Inject inline dead code using opaque predicates.
     *
     * Pattern:
     *   if ((CONST * CONST) < 0) {  // Always false: x*x >= 0 for any int... mostly
     *       ... junk code ...
     *   }
     *
     * Alternative patterns:
     *   if ((x | ~x) != -1) { ... }    // Always false
     *   if ((x & 0) != 0) { ... }      // Always false
     */
    private int injectInlineDeadCode(MethodNode method) {
        int injected = 0;
        int maxInjections = config.isAggressiveMode() ? 15 : 5;

        // ── Size Tracker: estimate current method size before injecting ──
        int currentSize = estimateBytecodeSize(method.instructions);
        if (currentSize >= SAFE_METHOD_BYTES) {
            return 0; // Already too large, skip entirely
        }

        InsnList insns = method.instructions;
        List<AbstractInsnNode> insertionPoints = findInsertionPoints(insns);

        Collections.shuffle(insertionPoints, random);
        int count = Math.min(maxInjections, insertionPoints.size());

        for (int i = 0; i < count; i++) {
            InsnList deadCode = generateOpaquePredicateBlock();
            int blockSize = estimateBytecodeSize(deadCode);

            // ── Size Tracker: abort if this block would breach the 60KB safety threshold ──
            if (currentSize + blockSize >= SAFE_METHOD_BYTES) {
                break;
            }

            AbstractInsnNode insertBefore = insertionPoints.get(i);
            insns.insertBefore(insertBefore, deadCode);
            currentSize += blockSize;
            injected++;
        }

        // Increase max stack to accommodate injected code
        method.maxStack = Math.max(method.maxStack + 4, 8);
        method.maxLocals = Math.max(method.maxLocals + 2, 4);

        return injected;
    }

    /**
     * Find safe insertion points within a method.
     * We look for positions between independent statements (after xSTORE, INVOKE, POP, etc.)
     */
    private List<AbstractInsnNode> findInsertionPoints(InsnList insns) {
        List<AbstractInsnNode> points = new ArrayList<>();

        for (AbstractInsnNode insn = insns.getFirst(); insn != null; insn = insn.getNext()) {
            if (insn.getNext() == null) continue;

            int opcode = insn.getOpcode();
            // Safe to insert after stores, invocations (void), pops
            if ((opcode >= Opcodes.ISTORE && opcode <= Opcodes.ASTORE) ||
                    opcode == Opcodes.POP || opcode == Opcodes.POP2) {

                // Don't insert right before a jump target or return
                AbstractInsnNode next = insn.getNext();
                if (next.getType() != AbstractInsnNode.LABEL &&
                        next.getOpcode() != Opcodes.RETURN &&
                        next.getType() != AbstractInsnNode.FRAME) {
                    points.add(next);
                }
            }
        }

        return points;
    }

    /**
     * Generate a dead code block guarded by an opaque predicate.
     * The predicate always evaluates to false, so the code never executes.
     */
    private InsnList generateOpaquePredicateBlock() {
        InsnList insns = new InsnList();
        LabelNode skipLabel = new LabelNode();

        int predicateType = random.nextInt(4);
        switch (predicateType) {
            case 0:
                // Opaque predicate: (CONST * CONST + 1) < 0
                // For non-overflow ints, x*x+1 > 0 always
                pushInt(insns, 2 + random.nextInt(100));
                insns.add(new InsnNode(Opcodes.DUP));
                insns.add(new InsnNode(Opcodes.IMUL));
                insns.add(new InsnNode(Opcodes.ICONST_1));
                insns.add(new InsnNode(Opcodes.IADD));
                insns.add(new JumpInsnNode(Opcodes.IFGE, skipLabel)); // Always taken
                break;

            case 1:
                // Opaque predicate: (0 & RANDOM) != 0 → always false
                insns.add(new InsnNode(Opcodes.ICONST_0));
                pushInt(insns, random.nextInt());
                insns.add(new InsnNode(Opcodes.IAND));
                insns.add(new JumpInsnNode(Opcodes.IFEQ, skipLabel)); // Always taken
                break;

            case 2:
                // Opaque predicate: Integer.MAX_VALUE + 1 > 0 → false (overflow)
                // Actually: we use a simpler always-false
                pushInt(insns, 0);
                pushInt(insns, 1);
                insns.add(new JumpInsnNode(Opcodes.IF_ICMPLT, skipLabel)); // 0 < 1, always taken
                break;

            case 3:
                // Opaque predicate: (CONST | CONST) == 0 → always false for non-zero
                pushInt(insns, 1 + random.nextInt(1000));
                pushInt(insns, 1 + random.nextInt(1000));
                insns.add(new InsnNode(Opcodes.IOR));
                insns.add(new JumpInsnNode(Opcodes.IFNE, skipLabel)); // Always taken (non-zero OR non-zero)
                break;
        }

        // Dead code block (never executed)
        generateInlineJunkInstructions(insns);

        insns.add(skipLabel);
        return insns;
    }

    /**
     * Generate a few meaningless instructions for the dead code body.
     * Includes ElainaShield signature strings as easter eggs (never executed).
     */
    private static final String[] ELAINA_SIGNATURES = {
            "ElainaShield - Advanced Java Bytecode Obfuscator",
            "Elaina Best Waifu \u2764",
            "Protected by ElainaShield \u2728",
            "\u2592\u2593\u2588 ElainaShield v1.x \u2588\u2593\u2592",
            "If you can read this, you're wasting your time :)",
            "Elaina the Ashen Witch protects this code \u2728",
            "\u039c\u03b1\u03b3\u03b9\u03b1 \u0394\u03b5 \u0395\u03bb\u03b1\u03b9\u03bd\u03b1 \u2605",
    };

    private void generateInlineJunkInstructions(InsnList insns) {
        int count = 15 + random.nextInt(25);
        for (int i = 0; i < count; i++) {
            int type = random.nextInt(6);
            switch (type) {
                case 0:
                    pushInt(insns, random.nextInt());
                    insns.add(new InsnNode(Opcodes.POP));
                    break;
                case 1:
                    pushInt(insns, random.nextInt(100));
                    pushInt(insns, random.nextInt(100) + 1);
                    insns.add(new InsnNode(Opcodes.IMUL));
                    insns.add(new InsnNode(Opcodes.POP));
                    break;
                case 2:
                    // One Elaina signature per class, rest is garbage
                    String str;
                    if (!elainaPlacedInCurrentClass && random.nextInt(5) == 0) {
                        str = ELAINA_SIGNATURES[random.nextInt(ELAINA_SIGNATURES.length)];
                        elainaPlacedInCurrentClass = true;
                    } else {
                        str = generateGarbageString();
                    }
                    insns.add(new LdcInsnNode(str));
                    insns.add(new InsnNode(Opcodes.POP));
                    break;
                case 3:
                    pushInt(insns, random.nextInt());
                    pushInt(insns, 1 + random.nextInt(31));
                    insns.add(new InsnNode(Opcodes.ISHR));
                    insns.add(new InsnNode(Opcodes.POP));
                    break;
                case 4:
                    insns.add(new InsnNode(Opcodes.ICONST_0));
                    insns.add(new InsnNode(Opcodes.I2L));
                    insns.add(new InsnNode(Opcodes.POP2));
                    break;
                case 5:
                    pushInt(insns, random.nextInt());
                    pushInt(insns, random.nextInt());
                    insns.add(new InsnNode(Opcodes.IADD));
                    insns.add(new InsnNode(Opcodes.POP));
                    break;
            }
        }
    }

    // ==================================================================
    // UTILITY
    // ==================================================================

    private void pushInt(InsnList insns, int value) {
        if (value >= -1 && value <= 5) {
            insns.add(new InsnNode(Opcodes.ICONST_0 + value));
        } else if (value >= Byte.MIN_VALUE && value <= Byte.MAX_VALUE) {
            insns.add(new IntInsnNode(Opcodes.BIPUSH, value));
        } else if (value >= Short.MIN_VALUE && value <= Short.MAX_VALUE) {
            insns.add(new IntInsnNode(Opcodes.SIPUSH, value));
        } else {
            insns.add(new LdcInsnNode(value));
        }
    }

    private int randomRange(int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    // ==================================================================
    // SIZE TRACKER — 64KB Method Limit Protection
    // ==================================================================

    /**
     * Estimate the bytecode size (in bytes) of an instruction list.
     * This is a conservative approximation — each opcode type has a known
     * encoding size in the JVM class file format.
     *
     * Reference: JVM Spec §6.5 (Instruction Set)
     */
    private int estimateBytecodeSize(InsnList insns) {
        int size = 0;
        for (AbstractInsnNode insn = insns.getFirst(); insn != null; insn = insn.getNext()) {
            size += estimateInsnSize(insn);
        }
        return size;
    }

    private int estimateInsnSize(AbstractInsnNode insn) {
        switch (insn.getType()) {
            case AbstractInsnNode.INSN:
                return 1; // Simple opcode (NOP, POP, IADD, IRETURN, etc.)
            case AbstractInsnNode.INT_INSN:
                return insn.getOpcode() == Opcodes.SIPUSH ? 3 : 2; // BIPUSH=2, SIPUSH=3, NEWARRAY=2
            case AbstractInsnNode.VAR_INSN: {
                int var = ((VarInsnNode) insn).var;
                // ILOAD_0..ALOAD_3 = 1 byte, otherwise xLOAD + index (2 or 4 bytes for wide)
                if (var <= 3) return 1;
                return var <= 255 ? 2 : 4; // wide prefix adds 2 extra bytes
            }
            case AbstractInsnNode.TYPE_INSN:
                return 3; // NEW, CHECKCAST, INSTANCEOF, ANEWARRAY
            case AbstractInsnNode.FIELD_INSN:
                return 3; // GETFIELD, PUTFIELD, GETSTATIC, PUTSTATIC
            case AbstractInsnNode.METHOD_INSN:
                return insn.getOpcode() == Opcodes.INVOKEINTERFACE ? 5 : 3;
            case AbstractInsnNode.INVOKE_DYNAMIC_INSN:
                return 5; // INVOKEDYNAMIC
            case AbstractInsnNode.JUMP_INSN:
                return 3; // GOTO, IF_ICMPEQ, etc. (could be 5 for GOTO_W but rare)
            case AbstractInsnNode.LDC_INSN: {
                Object cst = ((LdcInsnNode) insn).cst;
                // LDC = 2 bytes, LDC_W/LDC2_W = 3 bytes
                if (cst instanceof Long || cst instanceof Double) return 3;
                return 3; // Conservative: assume LDC_W
            }
            case AbstractInsnNode.IINC_INSN:
                return ((IincInsnNode) insn).var <= 255 ? 3 : 6; // IINC or wide IINC
            case AbstractInsnNode.TABLESWITCH_INSN: {
                TableSwitchInsnNode ts = (TableSwitchInsnNode) insn;
                // 1 + padding(0-3) + 4(default) + 4(low) + 4(high) + 4*N(targets)
                return 1 + 3 + 12 + 4 * (ts.max - ts.min + 1);
            }
            case AbstractInsnNode.LOOKUPSWITCH_INSN: {
                LookupSwitchInsnNode ls = (LookupSwitchInsnNode) insn;
                // 1 + padding(0-3) + 4(default) + 4(npairs) + 8*N(key+target pairs)
                return 1 + 3 + 8 + 8 * ls.keys.size();
            }
            case AbstractInsnNode.MULTIANEWARRAY_INSN:
                return 4; // MULTIANEWARRAY
            case AbstractInsnNode.LABEL:
            case AbstractInsnNode.FRAME:
            case AbstractInsnNode.LINE:
                return 0; // Pseudo-instructions, no bytecode
            default:
                return 1; // Unknown — conservative estimate
        }
    }
}
